
  
 const products = [
  {
    id: 1,
    name: 'MacBook Air 15,3" - temně inkoustový',
    price: 26990,
    rating: '★★★★★',
    image: 'https://istyle.cz/media/catalog/product/cache/image/700x700/e9c3970ab036de70892d86c6d221abfe/m/a/macbook_air_15_in_m3_midnight_pdp_image_position_1__en-us_3.jpg'
  },
  {
    id: 2,
    name: 'Apple iPhone 16 128GB - ultramarínový',
    price: 20890,
    rating: '★★★★☆',
    image: 'https://doc.iwant.cz/pic/4b7ed1ac73c946d8ba80f21a60caab64-600-600.webp'
  },
  {
    id: 3,
    name: 'AirPods 4',
    price: 3290,
    rating: '★★★★★',
    image: 'https://istyle.cz/media/catalog/product/cache/image/700x700/e9c3970ab036de70892d86c6d221abfe/a/i/airpods_4_pdp_image_position_1__cs-cz.jpg'
  },
  {
    id: 4,
    name: 'Apple 11palcový iPad Pro 256GB - vesmírně černý',
    price: 27990,
    rating: '★★★★☆',
    image: 'https://istyle.cz/media/catalog/product/cache/image/e9c3970ab036de70892d86c6d221abfe/i/p/ipad_pro_11_m4_wifi_space_black_pdp_image_position_1a__cs-cz.jpg'
  },
  {
    id: 5,
    name: 'MacBook Air 15,3" - temně inkoustový',
    price: 26990,
    rating: '★★★★★',
    image: 'https://istyle.cz/media/catalog/product/cache/image/700x700/e9c3970ab036de70892d86c6d221abfe/m/a/macbook_air_15_in_m3_midnight_pdp_image_position_1__en-us_3.jpg'
  },
  {
    id: 6,
    name: 'Apple iPhone 16 128GB - ultramarínový',
    price: 20890,
    rating: '★★★★☆',
    image: 'https://doc.iwant.cz/pic/4b7ed1ac73c946d8ba80f21a60caab64-600-600.webp'
  },
  {
    id: 7,
    name: 'AirPods 4',
    price: 3290,
    rating: '★★★★★',
    image: 'https://istyle.cz/media/catalog/product/cache/image/700x700/e9c3970ab036de70892d86c6d221abfe/a/i/airpods_4_pdp_image_position_1__cs-cz.jpg'
  },
  {
    id: 8,
    name: 'Apple 11palcový iPad Pro 256GB - vesmírně černý',
    price: 27990,
    rating: '★★★★☆',
    image: 'https://istyle.cz/media/catalog/product/cache/image/e9c3970ab036de70892d86c6d221abfe/i/p/ipad_pro_11_m4_wifi_space_black_pdp_image_position_1a__cs-cz.jpg'
  }
];

function displayProducts() {
  const productList = document.getElementById('product-list');
  productList.innerHTML = '';
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.className = 'product';
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="nazev">${product.name}</div>
      <div class="rating">${product.rating}</div>
      <div class="price">${product.price.toLocaleString()} zakarpastkich forint</div>
      <button class="button" onclick="addToCart('${product.name}', ${product.price})">V košík</button>
    `;
    productList.appendChild(productCard);
  });
}

window.onload = () => {
  displayProducts();
};












let cart = [];

function addToCart(name, price) {
    const existing = cart.find(item => item.name === name);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }
    updateCartIcon();
    alert('Produkt přidán do košíku.');
}

function updateCartIcon() {
    document.getElementById('cart-count').textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
}

function showCart() {
    let itemsHTML = '';
    cart.forEach((item, index) => {
        itemsHTML += `
            <li>
                <div class="cart-item-info">
                    ${item.name} - ${item.price} Kč
                </div>
                <div class="cart-item-actions">
                    <input type="number" min="1" value="${item.quantity}" onchange="changeQuantity(${index}, this.value)">
                    <button onclick="removeItem(${index})">🗑️</button>
                </div>
            </li>`;
    });

    document.getElementById('cart-items').innerHTML = itemsHTML || "<li>Košík je prázdný.</li>";
    updateTotal();
    document.getElementById('cart-modal').style.display = 'block';
}

function changeQuantity(index, value) {
    const qty = parseInt(value);
    if (qty > 0) {
        cart[index].quantity = qty;
    } else {
        removeItem(index);
    }
    showCart();
    updateCartIcon();
}

function updateTotal() {
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.getElementById('cart-total').textContent = `Celkem: ${total.toLocaleString()} Kč`;
}

function removeItem(index) {
    cart.splice(index, 1);
    showCart();
    updateCartIcon();
}

function closeCart() {
    document.getElementById('cart-modal').style.display = 'none';
}
function placeOrder() {
    if (cart.length === 0) {
        alert("Váš košík je prázdný!");
        return;
    }

    let summary = cart.map(item => `${item.name} x${item.quantity}`).join('\n');
    alert(`Děkujeme za objednávku!\n\nObjednal jste:\n${summary}`);

    // Очистить корзину
    cart = [];
    updateCartIcon();
    closeCart();
}
function removeFromCartAll() {
    cart = [];
    alert('Odebraly  jste vse!')
    updateCartIcon();
    closeCart();
}


let currentSlide = 0;

function displayProducts() {
  const productList = document.getElementById('product-list');
  productList.innerHTML = '';
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.className = 'product';
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="nazev">${product.name}</div>
      <div class="rating">${product.rating}</div>
      <div class="price">${product.price.toLocaleString()} Kč</div>
      <button class="button" onclick="addToCart('${product.name}', ${product.price})">V košík</button>
    `;
    productList.appendChild(productCard);
  });
  updateCarousel();
}

function updateCarousel() {
  const productList = document.getElementById('product-list');
  const cardWidth = 230; // width + margin of one product card
  productList.style.transform = `translateX(-${currentSlide * cardWidth}px)`;
}

document.getElementById('next').addEventListener('click', () => {
  if ((currentSlide + 4) < products.length) {
    currentSlide += 1;
    updateCarousel();
  }
});

document.getElementById('prev').addEventListener('click', () => {
  if (currentSlide > 0) {
    currentSlide -= 1;
    updateCarousel();
  }
});

window.onload = () => {
  displayProducts();
};
